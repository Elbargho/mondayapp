num_helps = 6
num_freehelps = 4
grade = 95
user_rating = 4.6
succeeded_helps = 6


def rank_valuation(num_freehelps, num_helps, grade, user_rating, succeeded_helps):
    score = 0
    honor_star = 0
    if num_freehelps >= 5:
        honor_star = num_freehelps // 5
        score += honor_star

    if grade >= 95:
        score += 1
    elif grade < 95:
        score += grade/100
    if num_helps >= 10 & succeeded_helps == num_helps:
        score += 2
    elif num_helps >= 5:
        score += 1+(succeeded_helps/num_helps)
    else:
        score += (succeeded_helps/num_helps)

    score += user_rating/5
    return score


score = rank_valuation(num_freehelps, num_helps, grade,
                       user_rating, succeeded_helps)
print(score)

honor_star = num_freehelps // 5

print(honor_star)
