import requests
import json

apiKey = "eyJhbGciOiJIUzI1NiJ9.eyJ0aWQiOjE2MDI1MTQyMywidWlkIjozMDQwODY1MCwiaWFkIjoiMjAyMi0wNS0xMlQxNToxNzoyMC4wMDBaIiwicGVyIjoibWU6d3JpdGUiLCJhY3RpZCI6MTIxMjY5NzAsInJnbiI6InVzZTEifQ.2ycFgTnH8Bs2xJIab8YSvQZ5_WHw5eBrq2fgAOsQQ0E"
apiUrl = "https://api.monday.com/v2"
headers = {"Authorization": apiKey}

createTableQuery = ''' mutation{
  create_item(board_id: 2661474689, item_name: "row2"){
    id
    name
  }
}
'''
createColumnsQuery = '''mutation{
  create_column(board_id: 2661474689, title:"Work Status", description: "This is my work status column", column_type:status) {
    id
    title
    description
  }
}
'''

pushDataQuery = '''query{
  boards(ids:2661474689){
    items{
    id
    name
  }
}

}
'''

board_id = None


def createBoard():
    global board_id
    query = createBoard
    data = {'query': query}
    r = requests.post(url=apiUrl, json=data, headers=headers)  # make request
    board_id = r.json()['data']['create_board']['id']


def createColumns():
    query = createColumns
    data = {'query': query}
    r = requests.post(url=apiUrl, json=data, headers=headers)  # make request

def pushData():
    query = pushData
    data = {'query': query}
    r = requests.post(url=apiUrl, json=data, headers=headers)  # make request
