let courseOfferForm = document.querySelector('#courseOfferForm');
if (courseOfferForm != null) {
    let courseOffer = courseOfferForm.firstElementChild;
}

function addCourseOffer() {
    let newCourseOffer = courseOffer.cloneNode(deep = true);
    newCourseOffer.className += ' mt-4';
    courseOfferForm.appendChild(newCourseOffer);
}

function pad(h, m) {
    nh = h.toString();
    nm = m.toString();
    if (h < 10) {
        nh = '0' + nh;
    }
    if (m < 10) {
        nm = '0' + nm;
    }
    return `${nh}:${nm}`;
}

function addTimes() {
    let timesLst = document.querySelector('#times');
    for (var h = 0; h < 24; h++) {
        for (var m = 0; m < 60; m += 10) {
            let option = document.createElement('option');
            option.setAttribute('value', pad(h, m));
            timesLst.appendChild(option);
        }
    }
}

addTimes();