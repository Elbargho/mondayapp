from flask import Flask, redirect, url_for, render_template, request, session
import random

app = Flask(__name__)
app.secret_key = "ea0a33f7bd7d15a4fe9cb6d6cdcb5cb8a48873f4ed0e9fc87c6f76f0daefa899"


@app.route("/")
def index():
    return render_template("login.html")

@app.route("/login")
def login():
    return redirect(url_for('main'))

@app.route("/main")
def main():
    return render_template("main.html")

@app.route("/signup")
def signup():
    return render_template('signup.html')

@app.route("/request")
def request():
    return render_template('request.html')

@app.route("/allofferrers")
def getOfferrers():
    return render_template('allofferrers.html')

@app.route("/sendphonenumber", methods=["POST"])
def sendLoginCode():
    try:
        dataErr = "phone number is invalid"
        data = request.get_json()
        pn = data['pn']
        if(not(pn.isnumeric() and len(pn) == 10)):
            raise Exception(dataErr)
        session['pn'] = pn
        code = str(random.randint(1000, 9999))
        session['code'] = code
        print(code, flush=True)
        return {}, 200
    except Exception as e:
        print(e, flush=True)
        if(str(e) == dataErr):
            return {}, 400
        return {}, 500


@app.route("/sendlogincode", methods=["POST"])
def confirmLoginCode():
    try:
        dataErr = "code is invalid"
        data = request.get_json()
        code = data['code']
        auth = False
        if(code == session['code']):
            session['loggedIn'] = True
            auth = True
        return {'auth': auth, 'request': dbm.getRequest(session['pn'])}, 200
    except Exception as e:
        print(e, flush=True)
        if(str(e) == dataErr):
            return {}, 400
        return {}, 500


@app.route("/sendrequest", methods=["POST"])
def addRequest():
    try:
        authErr = "User trying to post a request without authentication"
        if("loggedIn" not in session):
            raise Exception(authErr)
        data = request.get_json()
        dbm.postRequest(session['pn'], data)
        return {}, 200
    except Exception as e:
        print(e, flush=True)
        if(str(e) == authErr):
            return {}, 400
        return {}, 500


@app.route("/cancelsubscription", methods=["POST"])
def cancelSubscription():
    try:
        dbm.turnSubscription(session['pn'], 0)
        return {}, 200
    except Exception as e:
        print(e, flush=True)
        return {}, 500


@app.route("/renewsubscription", methods=["POST"])
def renewSubscription():
    try:
        dbm.turnSubscription(session['pn'], 1)
        return {}, 200
    except Exception as e:
        print(e, flush=True)
        return {}, 500


@app.route("/logout", methods=["POST"])
def logout():
    try:
        session.clear()
        return {}, 200
    except Exception as e:
        print(e, flush=True)
        return {}, 500


if __name__ == "__main__":
    app.run(debug=True)
